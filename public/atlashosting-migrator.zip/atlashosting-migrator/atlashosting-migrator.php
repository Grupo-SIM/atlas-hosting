<?php
/*
Plugin Name: AtlasHosting Migrator
Plugin URI: https://yourplatform.com/
Description: A tool to help migrate WordPress sites to AtlasHosting. This is the main plugin file and entry point.
Version: 0.1.0
Author: AtlasHosting Team
Author URI: https://yourplatform.com/
License: GPL2
Text Domain: atlashosting-migrator
*/

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants (for paths, version, etc.)
define('AHM_PLUGIN_VERSION', '0.1.0');
define('AHM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AHM_PLUGIN_URL', plugin_dir_url(__FILE__));

defined('ABSPATH') or die('No script kiddies please!');

// Include required files (admin, public, etc.)
require_once AHM_PLUGIN_DIR . 'includes/class-ahm-security-helper.php';
require_once AHM_PLUGIN_DIR . 'includes/class-ahm-export-handler.php';

// Register activation and deactivation hooks
register_activation_hook(__FILE__, 'ahm_activate_plugin');
register_deactivation_hook(__FILE__, 'ahm_deactivate_plugin');

function ahm_activate_plugin() {
    // TODO: Add activation logic (e.g., create custom tables, options)
}

function ahm_deactivate_plugin() {
    // Clear scheduled exports cleanup
    wp_clear_scheduled_hook('ahm_cleanup_exports');
    
    // Cleanup any remaining export files
    if (class_exists('AHM_Export_Handler')) {
        $export_handler = new AHM_Export_Handler();
        $export_handler->cleanup_old_exports();
    }
}

// Initialize the plugin
add_action('plugins_loaded', 'ahm_init_plugin');

function ahm_init_plugin() {
    // Load text domain for translations
    load_plugin_textdomain('atlashosting-migrator', false, dirname(plugin_basename(__FILE__)) . '/languages');
    
    // Initialize export handler
    if (class_exists('AHM_Export_Handler')) {
        new AHM_Export_Handler();
    }
    
    // Schedule cleanup of old exports
    if (!wp_next_scheduled('ahm_cleanup_exports')) {
        wp_schedule_event(time(), 'hourly', 'ahm_cleanup_exports');
    }
}

// Next steps:
// - Create an 'includes' directory for core logic (classes, helpers)
// - Create an 'admin' directory for admin dashboard UI
// - Create a 'public' directory for frontend hooks (if needed)
// - Implement migration logic, AJAX handlers, and REST API endpoints
// - Add settings page for configuration
// - Add security checks and nonce verification
// - Write documentation and inline comments

add_action('admin_menu', 'ahm_register_admin_page');
function ahm_register_admin_page() {
    add_menu_page(
        __('AtlasHosting Migration', 'atlashosting-migrator'),
        'AtlasHosting',
        'manage_options',
        'atlashosting-migrator',
        'ahm_render_admin_page',
        'dashicons-migrate', // Choose an appropriate icon
        65
    );
}

function ahm_render_admin_page() {
    echo '<div id="ahm-admin-root"></div>'; // React will mount here
}

add_action('admin_enqueue_scripts', 'ahm_enqueue_admin_assets');
function ahm_enqueue_admin_assets($hook) {
    if ($hook !== 'toplevel_page_atlashosting-migrator') {
        return;
    }
    
    // Adjust paths as needed
    wp_enqueue_script(
        'ahm-admin-js',
        plugins_url('admin/build/static/js/main.js', __FILE__),
        array('wp-element'), // depends on React in WP
        AHM_PLUGIN_VERSION,
        true
    );
    wp_enqueue_style(
        'ahm-admin-css',
        plugins_url('admin/build/static/css/main.css', __FILE__),
        array(),
        AHM_PLUGIN_VERSION
    );
    
    // Localize script with AJAX data
    wp_localize_script('ahm-admin-js', 'ahmAjax', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ahm_export_data'),
        'strings' => array(
            'exportStarted' => __('Exportação iniciada...', 'atlashosting-migrator'),
            'exportCompleted' => __('Exportação concluída!', 'atlashosting-migrator'),
            'exportError' => __('Erro durante a exportação.', 'atlashosting-migrator'),
            'downloadReady' => __('Download pronto!', 'atlashosting-migrator')
        )
    ));
}

// Hook for scheduled cleanup
add_action('ahm_cleanup_exports', 'ahm_scheduled_cleanup');
function ahm_scheduled_cleanup() {
    if (class_exists('AHM_Export_Handler')) {
        $export_handler = new AHM_Export_Handler();
        $export_handler->cleanup_old_exports();
    }
}

?> 