<?php
/**
 * AtlasHosting Migration Export Handler
 * 
 * Handles secure export of WordPress files and database
 * 
 * @package AtlasHosting_Migrator
 * @since 0.1.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AHM_Export_Handler {
    
    /**
     * Export directory name
     */
    const EXPORT_DIR = 'atlashosting-exports';
    
    /**
     * Maximum file size (100MB)
     */
    const MAX_FILE_SIZE = 100 * 1024 * 1024;
    
    /**
     * Security nonce action
     */
    const NONCE_ACTION = 'ahm_export_data';
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('wp_ajax_ahm_export_data', array($this, 'handle_export_request'));
        add_action('wp_ajax_ahm_download_export', array($this, 'handle_download_request'));
        add_action('wp_ajax_ahm_cleanup_exports', array($this, 'cleanup_old_exports'));
    }
    
    /**
     * Handle export request
     */
    public function handle_export_request() {
        try {
            // Security checks
            if (!$this->verify_security()) {
                wp_die(__('Acesso negado.', 'atlashosting-migrator'));
            }
            
            // Increase execution time and memory for large exports
            @ini_set('max_execution_time', 0);
            @ini_set('memory_limit', '512M');
            
            // Create export
            $export_data = $this->create_full_export();
            
            wp_send_json_success($export_data);
            
        } catch (Exception $e) {
            error_log('AHM Export Error: ' . $e->getMessage());
            wp_send_json_error(__('Erro durante a exportação: ', 'atlashosting-migrator') . $e->getMessage());
        }
    }
    
    /**
     * Handle download request
     */
    public function handle_download_request() {
        if (!$this->verify_security()) {
            wp_die(__('Acesso negado.', 'atlashosting-migrator'));
        }
        
        $export_id = sanitize_text_field($_GET['export_id'] ?? '');
        if (empty($export_id) || !AHM_Security_Helper::validate_export_id($export_id)) {
            AHM_Security_Helper::log_security_event('download_invalid_export_id', array('export_id' => $export_id));
            wp_die(__('ID de exportação inválido.', 'atlashosting-migrator'));
        }
        
        $this->serve_export_file($export_id);
    }
    
    /**
     * Verify security (nonce, permissions, etc.)
     */
    private function verify_security() {
        // Use security helper for comprehensive checks
        if (!AHM_Security_Helper::can_export()) {
            AHM_Security_Helper::log_security_event('export_access_denied');
            return false;
        }
        
        // Check nonce
        $nonce = $_REQUEST['_wpnonce'] ?? '';
        if (!wp_verify_nonce($nonce, 'ahm_export_data')) {
            AHM_Security_Helper::log_security_event('export_invalid_nonce');
            return false;
        }
        
        // Record the attempt for rate limiting
        AHM_Security_Helper::record_export_attempt();
        
        return true;
    }
    
    /**
     * Create full WordPress export
     */
    private function create_full_export() {
        $export_id = $this->generate_export_id();
        $export_dir = $this->get_export_directory($export_id);
        
        // Create export directory
        if (!wp_mkdir_p($export_dir)) {
            throw new Exception(__('Não foi possível criar o diretório de exportação.', 'atlashosting-migrator'));
        }
        
        // Export database
        $db_file = $this->export_database($export_dir);
        
        // Export files
        $files_exported = $this->export_files($export_dir);
        
        // Create zip file
        $zip_file = $this->create_zip_archive($export_dir, $export_id);
        
        // Cleanup temporary files
        $this->cleanup_temp_files($export_dir, $zip_file);
        
        return array(
            'export_id' => $export_id,
            'download_url' => $this->get_download_url($export_id),
            'file_size' => filesize($zip_file),
            'file_count' => $files_exported,
            'db_exported' => !empty($db_file),
            'created_at' => current_time('mysql')
        );
    }
    
    /**
     * Export database as CSV files
     */
    private function export_database($export_dir) {
        global $wpdb;
        
        $db_dir = $export_dir . '/database';
        wp_mkdir_p($db_dir);
        
        // Get all WordPress tables
        $tables = $wpdb->get_results("SHOW TABLES LIKE '{$wpdb->prefix}%'", ARRAY_N);
        
        $exported_files = array();
        
        foreach ($tables as $table) {
            $table_name = $table[0];
            $csv_file = $db_dir . '/' . $table_name . '.csv';
            
            $this->export_table_to_csv($table_name, $csv_file);
            $exported_files[] = $csv_file;
        }
        
        // Create database info file
        $db_info = array(
            'wordpress_version' => get_bloginfo('version'),
            'php_version' => PHP_VERSION,
            'mysql_version' => $wpdb->db_version(),
            'site_url' => get_site_url(),
            'home_url' => get_home_url(),
            'admin_email' => get_option('admin_email'),
            'timezone' => get_option('timezone_string'),
            'export_date' => current_time('mysql'),
            'tables_exported' => count($exported_files)
        );
        
        file_put_contents(
            $db_dir . '/database_info.json',
            json_encode($db_info, JSON_PRETTY_PRINT)
        );
        
        return $exported_files;
    }
    
    /**
     * Export table to CSV
     */
    private function export_table_to_csv($table_name, $csv_file) {
        global $wpdb;
        
        $handle = fopen($csv_file, 'w');
        if (!$handle) {
            throw new Exception("Não foi possível criar o arquivo CSV para a tabela: {$table_name}");
        }
        
        // Get column names
        $columns = $wpdb->get_results("DESCRIBE {$table_name}", ARRAY_A);
        $column_names = array_column($columns, 'Field');
        
        // Write header
        fputcsv($handle, $column_names);
        
        // Export data in chunks to handle large tables
        $offset = 0;
        $chunk_size = 1000;
        
        do {
            $results = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM {$table_name} LIMIT %d OFFSET %d",
                    $chunk_size,
                    $offset
                ),
                ARRAY_A
            );
            
            foreach ($results as $row) {
                fputcsv($handle, $row);
            }
            
            $offset += $chunk_size;
            
        } while (count($results) === $chunk_size);
        
        fclose($handle);
    }
    
    /**
     * Export important WordPress files
     */
    private function export_files($export_dir) {
        $files_dir = $export_dir . '/files';
        wp_mkdir_p($files_dir);
        
        $file_count = 0;
        
        // Important directories to export
        $important_dirs = array(
            'wp-content/themes' => 'themes',
            'wp-content/plugins' => 'plugins',
            'wp-content/uploads' => 'uploads',
            'wp-content/mu-plugins' => 'mu-plugins'
        );
        
        foreach ($important_dirs as $source_dir => $dest_dir) {
            $source_path = ABSPATH . $source_dir;
            $dest_path = $files_dir . '/' . $dest_dir;
            
            if (is_dir($source_path)) {
                $file_count += $this->copy_directory($source_path, $dest_path);
            }
        }
        
        // Export important root files
        $important_files = array(
            'wp-config.php',
            '.htaccess',
            'robots.txt',
            'favicon.ico'
        );
        
        $root_dir = $files_dir . '/root';
        wp_mkdir_p($root_dir);
        
        foreach ($important_files as $file) {
            $source_file = ABSPATH . $file;
            $dest_file = $root_dir . '/' . $file;
            
            if (file_exists($source_file)) {
                if ($file === 'wp-config.php') {
                    // Sanitize wp-config.php (remove sensitive data)
                    $this->export_sanitized_wp_config($source_file, $dest_file);
                } else {
                    copy($source_file, $dest_file);
                }
                $file_count++;
            }
        }
        
        // Create file manifest
        $this->create_file_manifest($files_dir, $file_count);
        
        return $file_count;
    }
    
    /**
     * Copy directory recursively
     */
    private function copy_directory($source, $destination) {
        $file_count = 0;
        
        if (!is_dir($source)) {
            return $file_count;
        }
        
        wp_mkdir_p($destination);
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $item) {
            $relative_path = str_replace($source . DIRECTORY_SEPARATOR, '', $item->getPathname());
            $dest_path = $destination . DIRECTORY_SEPARATOR . $relative_path;
            
            if ($item->isDir()) {
                wp_mkdir_p($dest_path);
            } else {
                // Skip large files
                if ($item->getSize() > self::MAX_FILE_SIZE) {
                    continue;
                }
                
                // Skip cache and temporary files
                if ($this->should_skip_file($item->getPathname())) {
                    continue;
                }
                
                // Additional security check
                if (!AHM_Security_Helper::is_file_secure_for_export($item->getPathname())) {
                    continue;
                }
                
                copy($item->getPathname(), $dest_path);
                $file_count++;
            }
        }
        
        return $file_count;
    }
    
    /**
     * Check if file should be skipped
     */
    private function should_skip_file($file_path) {
        $skip_patterns = array(
            '/cache/',
            '/tmp/',
            '/temp/',
            '/logs/',
            '.log',
            '.tmp',
            'error_log',
            'debug.log'
        );
        
        foreach ($skip_patterns as $pattern) {
            if (strpos($file_path, $pattern) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Export sanitized wp-config.php
     */
    private function export_sanitized_wp_config($source_file, $dest_file) {
        $config_content = file_get_contents($source_file);
        
        // Remove sensitive database credentials
        $config_content = preg_replace(
            "/define\(\s*['\"]DB_(NAME|USER|PASSWORD|HOST)['\"]\s*,\s*['\"][^'\"]*['\"]\s*\);/",
            "// DB credentials removed for security",
            $config_content
        );
        
        // Remove security keys and salts
        $config_content = preg_replace(
            "/define\(\s*['\"]((AUTH|SECURE_AUTH|LOGGED_IN|NONCE)_KEY|(AUTH|SECURE_AUTH|LOGGED_IN|NONCE)_SALT)['\"]\s*,\s*['\"][^'\"]*['\"]\s*\);/",
            "// Security keys removed",
            $config_content
        );
        
        file_put_contents($dest_file, $config_content);
    }
    
    /**
     * Create file manifest
     */
    private function create_file_manifest($files_dir, $file_count) {
        $manifest = array(
            'total_files' => $file_count,
            'export_date' => current_time('mysql'),
            'wordpress_version' => get_bloginfo('version'),
            'site_url' => get_site_url(),
            'directories' => array()
        );
        
        $dirs = glob($files_dir . '/*', GLOB_ONLYDIR);
        foreach ($dirs as $dir) {
            $dir_name = basename($dir);
            $manifest['directories'][$dir_name] = $this->count_files_in_directory($dir);
        }
        
        file_put_contents(
            $files_dir . '/manifest.json',
            json_encode($manifest, JSON_PRETTY_PRINT)
        );
    }
    
    /**
     * Count files in directory
     */
    private function count_files_in_directory($dir) {
        $count = 0;
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $count++;
            }
        }
        
        return $count;
    }
    
    /**
     * Create ZIP archive
     */
    private function create_zip_archive($export_dir, $export_id) {
        if (!class_exists('ZipArchive')) {
            throw new Exception(__('Extensão ZipArchive não está disponível.', 'atlashosting-migrator'));
        }
        
        $zip_file = $this->get_export_directory() . '/' . $export_id . '.zip';
        $zip = new ZipArchive();
        
        if ($zip->open($zip_file, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
            throw new Exception(__('Não foi possível criar o arquivo ZIP.', 'atlashosting-migrator'));
        }
        
        $this->add_directory_to_zip($zip, $export_dir, '');
        $zip->close();
        
        return $zip_file;
    }
    
    /**
     * Add directory to ZIP
     */
    private function add_directory_to_zip($zip, $source_dir, $archive_path) {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source_dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            $file_path = $file->getRealPath();
            $relative_path = str_replace($source_dir . DIRECTORY_SEPARATOR, '', $file_path);
            $relative_path = $archive_path . $relative_path;
            
            if ($file->isDir()) {
                $zip->addEmptyDir($relative_path);
            } else {
                $zip->addFile($file_path, $relative_path);
            }
        }
    }
    
    /**
     * Serve export file for download
     */
    private function serve_export_file($export_id) {
        $zip_file = $this->get_export_directory() . '/' . $export_id . '.zip';
        
        if (!file_exists($zip_file)) {
            wp_die(__('Arquivo de exportação não encontrado.', 'atlashosting-migrator'));
        }
        
        // Security check - ensure file is in export directory
        $real_path = realpath($zip_file);
        $export_real_path = realpath($this->get_export_directory());
        
        if (strpos($real_path, $export_real_path) !== 0) {
            wp_die(__('Acesso negado.', 'atlashosting-migrator'));
        }
        
        $file_size = filesize($zip_file);
        $file_name = 'atlashosting-export-' . $export_id . '.zip';
        
        // Set headers for download
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $file_name . '"');
        header('Content-Length: ' . $file_size);
        header('Cache-Control: private');
        header('Pragma: private');
        header('Expires: 0');
        
        // Output file
        readfile($zip_file);
        
        // Delete file after download for security
        unlink($zip_file);
        
        exit;
    }
    
    /**
     * Cleanup old export files
     */
    public function cleanup_old_exports() {
        $export_dir = $this->get_export_directory();
        
        if (!is_dir($export_dir)) {
            return;
        }
        
        $files = glob($export_dir . '/*.zip');
        $current_time = time();
        
        foreach ($files as $file) {
            // Delete files older than 1 hour
            if ($current_time - filemtime($file) > 3600) {
                unlink($file);
            }
        }
        
        // Also cleanup temporary directories
        $temp_dirs = glob($export_dir . '/export_*', GLOB_ONLYDIR);
        foreach ($temp_dirs as $dir) {
            if ($current_time - filemtime($dir) > 3600) {
                $this->remove_directory($dir);
            }
        }
    }
    
    /**
     * Cleanup temporary files
     */
    private function cleanup_temp_files($export_dir, $zip_file) {
        // Remove the temporary export directory
        $this->remove_directory($export_dir);
    }
    
    /**
     * Remove directory recursively
     */
    private function remove_directory($dir) {
        if (!is_dir($dir)) {
            return;
        }
        
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        
        foreach ($files as $file) {
            if ($file->isDir()) {
                rmdir($file->getRealPath());
            } else {
                unlink($file->getRealPath());
            }
        }
        
        rmdir($dir);
    }
    
    /**
     * Generate unique export ID
     */
    private function generate_export_id() {
        return 'export_' . date('Y-m-d_H-i-s') . '_' . wp_generate_password(8, false);
    }
    
    /**
     * Get export directory path
     */
    private function get_export_directory($export_id = '') {
        $upload_dir = wp_upload_dir();
        $base_dir = $upload_dir['basedir'] . '/' . self::EXPORT_DIR;
        
        if (!empty($export_id)) {
            return $base_dir . '/' . $export_id;
        }
        
        return $base_dir;
    }
    
    /**
     * Get download URL
     */
    private function get_download_url($export_id) {
        return add_query_arg(array(
            'action' => 'ahm_download_export',
            'export_id' => $export_id,
            '_wpnonce' => wp_create_nonce('ahm_export_data')
        ), admin_url('admin-ajax.php'));
    }
}

// Initialize the export handler
new AHM_Export_Handler();
