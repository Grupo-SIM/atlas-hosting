<?php
/**
 * Security Helper for AtlasHosting Migrator
 * 
 * Provides additional security functions for the export process
 * 
 * @package AtlasHosting_Migrator
 * @since 0.1.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AHM_Security_Helper {
    
    /**
     * Rate limiting for export requests
     */
    const RATE_LIMIT_KEY = 'ahm_export_attempts';
    const MAX_ATTEMPTS = 3;
    const RATE_LIMIT_WINDOW = 3600; // 1 hour
    
    /**
     * Check if user can perform export
     */
    public static function can_export() {
        // Check basic WordPress permissions
        if (!current_user_can('manage_options')) {
            return false;
        }
        
        // Check if user is super admin in multisite
        if (is_multisite() && !is_super_admin()) {
            return false;
        }
        
        // Check rate limiting
        if (!self::check_rate_limit()) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Check rate limiting for export attempts
     */
    private static function check_rate_limit() {
        $user_id = get_current_user_id();
        $attempts_key = self::RATE_LIMIT_KEY . '_' . $user_id;
        
        $attempts = get_transient($attempts_key);
        
        if ($attempts === false) {
            $attempts = 0;
        }
        
        if ($attempts >= self::MAX_ATTEMPTS) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Record export attempt
     */
    public static function record_export_attempt() {
        $user_id = get_current_user_id();
        $attempts_key = self::RATE_LIMIT_KEY . '_' . $user_id;
        
        $attempts = get_transient($attempts_key);
        
        if ($attempts === false) {
            $attempts = 0;
        }
        
        $attempts++;
        set_transient($attempts_key, $attempts, self::RATE_LIMIT_WINDOW);
    }
    
    /**
     * Sanitize file path
     */
    public static function sanitize_file_path($path) {
        // Remove any potential directory traversal attempts
        $path = str_replace(array('../', '..\\'), '', $path);
        
        // Remove null bytes
        $path = str_replace("\0", '', $path);
        
        // Remove any non-printable characters
        $path = preg_replace('/[^\x20-\x7E]/', '', $path);
        
        return $path;
    }
    
    /**
     * Validate export ID format
     */
    public static function validate_export_id($export_id) {
        // Export ID should match the pattern: export_YYYY-MM-DD_HH-MM-SS_XXXXXXXX
        return preg_match('/^export_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}_[a-zA-Z0-9]{8}$/', $export_id);
    }
    
    /**
     * Log security events
     */
    public static function log_security_event($event, $details = array()) {
        $log_entry = array(
            'timestamp' => current_time('mysql'),
            'user_id' => get_current_user_id(),
            'user_ip' => self::get_client_ip(),
            'event' => $event,
            'details' => $details
        );
        
        error_log('AHM Security Event: ' . wp_json_encode($log_entry));
    }
    
    /**
     * Get client IP address
     */
    private static function get_client_ip() {
        $ip_headers = array(
            'HTTP_CF_CONNECTING_IP',
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        );
        
        foreach ($ip_headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }
    
    /**
     * Check if file should be excluded from export for security
     */
    public static function is_file_secure_for_export($file_path) {
        $dangerous_files = array(
            '.htpasswd',
            '.ssh',
            'private.key',
            'id_rsa',
            'id_dsa',
            '.pem',
            '.p12',
            '.pfx'
        );
        
        $file_name = basename($file_path);
        $file_lower = strtolower($file_name);
        
        foreach ($dangerous_files as $dangerous) {
            if (strpos($file_lower, $dangerous) !== false) {
                return false;
            }
        }
        
        return true;
    }
}
