# AtlasHosting Migrator

A WordPress plugin to help users migrate their WordPress sites to AtlasHosting with ease.

## Purpose
This plugin will guide users through a step-by-step migration process, allowing them to transfer their site data, files, and configuration securely to the AtlasHosting platform.

## Features

### ✅ Secure Export System
- **Complete WordPress Export**: Exports all essential WordPress files including themes, plugins, uploads, and mu-plugins
- **Database Export**: Exports all WordPress database tables as CSV files for easy import
- **Security Features**: 
  - Rate limiting (max 3 exports per hour per user)
  - Nonce verification for all requests
  - User permission checks (requires `manage_options` capability)
  - Automatic cleanup of export files after download
  - Exclusion of sensitive files (SSH keys, private keys, etc.)
- **ZIP Archive**: Creates a compressed ZIP file containing all exported data
- **Auto-cleanup**: Automatically removes old export files after 1 hour

### 🔒 Security Measures
- WordPress nonce verification
- User capability checks
- Rate limiting for export requests
- Secure file path validation
- Automatic logging of security events
- Sanitized wp-config.php export (removes database credentials and security keys)

### 📦 Export Contents
- **WordPress Files**:
  - `wp-content/themes/` - All theme files
  - `wp-content/plugins/` - All plugin files
  - `wp-content/uploads/` - All media files
  - `wp-content/mu-plugins/` - Must-use plugins
  - Root files: `wp-config.php` (sanitized), `.htaccess`, `robots.txt`, `favicon.ico`
- **Database**: All WordPress tables exported as CSV files
- **Metadata**: Export manifest with file counts, timestamps, and WordPress info

## Installation

### For End Users
1. Download the latest plugin ZIP from the releases
2. Upload the ZIP file via WordPress Admin → Plugins → Add New → Upload Plugin
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Navigate to 'AtlasHosting' in your WordPress admin menu to begin migration

### For Developers
```bash
# Clone the repository
git clone <repository-url>
cd atlashosting-migrator

# Install dependencies and start development
./dev.sh install
./dev.sh dev
```

## Development

### Prerequisites
- [Bun](https://bun.sh) runtime
- PHP 7.4+
- WordPress development environment

### Development Commands
```bash
# Install dependencies
./dev.sh install

# Start development server
./dev.sh dev

# Build for production
./dev.sh build

# Create plugin package
./dev.sh package

# Clean build artifacts
./dev.sh clean

# Run linting
./dev.sh lint
```

### Building Plugin ZIP
To create a WordPress-ready plugin ZIP file:
```bash
./build.sh
```
This will create a `dist/atlashosting-migrator-{version}.zip` file ready for WordPress installation.

## Usage
1. **Step 1**: Welcome screen with migration overview
2. **Step 2**: Export your WordPress data
   - Click "Exportar Arquivos" to start the export process
   - Wait for the export to complete (progress is shown)
   - Download will start automatically upon completion
3. **Step 3**: Upload the exported ZIP file to your new AtlasHosting account

## Technical Details

### Export Process
1. Creates a temporary export directory in `wp-content/uploads/atlashosting-exports/`
2. Exports database tables to individual CSV files
3. Copies all important WordPress files while excluding cache and temporary files
4. Creates a manifest file with export metadata
5. Compresses everything into a ZIP archive
6. Provides secure download link
7. Automatically cleans up temporary files

### Security
- All export operations require admin privileges
- Rate limiting prevents abuse (3 exports per hour per user)
- Export files are automatically deleted after download
- Sensitive configuration data is sanitized before export
- All operations are logged for security monitoring

### File Size Limits
- Individual files larger than 100MB are skipped
- ZIP compression is used to minimize final archive size
- Memory and execution time limits are increased during export

## Development Notes
- Follow WordPress coding standards
- Ensure security best practices (nonces, sanitization, validation)
- Optimize for performance and compatibility
- All user-facing text is in Brazilian Portuguese

## Roadmap / Next Steps
- [x] ~~Create `includes/` for core logic (classes, helpers)~~
- [x] ~~Create secure export functionality~~
- [x] ~~Implement migration logic and AJAX handlers~~
- [x] ~~Add security checks and nonce verification~~
- [ ] Add progress indicators for large exports
- [ ] Implement selective export options (choose specific files/tables)
- [ ] Add export scheduling functionality
- [ ] Create import functionality for AtlasHosting
- [ ] Add export encryption options
- [ ] Implement export resume capability for interrupted exports

---
*Updated: June 22, 2025* 